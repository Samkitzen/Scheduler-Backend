main branch is the only production branch 
ched chad na kare


master is the working branch do whatever you want in master